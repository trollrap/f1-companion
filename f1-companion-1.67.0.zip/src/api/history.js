// Offline history of every Formula 1 season up to HISTORY_UPTO (generated from the open f1db dataset, see HANDOFF.md).
// Careers, past seasons, search lists and comparisons are answered from here in a few milliseconds instead of dozens of Jolpica requests.
// The current season (and anyone the file does not know, such as a 2026 rookie) still comes live from Jolpica.
import { driverChampion, constructorChampion, driverChampionYears, constructorChampionYears } from '../data/champions';

let H = null, IX = null;
const load = () => {
  if (H) return H;
  H = require('../data/history.json');
  const byDid = {}, byName = {}, byName2 = {}, famCount = {}, idOf = [], idMap = {}, tIdMap = {};
  const norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9 ]/g, '').replace(/\s+/g, ' ').trim();
  const strip = (s) => s.replace(/ (jr|sr)$/, '');
  const slug = (s) => norm(s).replace(/ /g, '_');
  H.d.forEach((d, i) => { famCount[slug(strip(norm(d[2])))] = (famCount[slug(strip(norm(d[2])))] || 0) + 1; });
  const lastYear = {}, firstYear = {};
  Object.keys(H.r).forEach((y) => H.r[y].forEach((rc) => rc[4].forEach((row) => { lastYear[row[0]] = +y; if (firstYear[row[0]] == null) firstYear[row[0]] = +y; })));
  H.d.forEach((d, i) => {
    const full = norm(`${d[1]} ${d[2]}`); (byName[full] = byName[full] || []).push(i);
    const k2 = norm(`${d[1]} ${strip(norm(d[2]))}`); (byName2[k2] = byName2[k2] || []).push(i);
    const fam = slug(strip(norm(d[2])));
    const id = famCount[fam] === 1 ? fam : `${slug(d[1])}_${slug(d[2])}`;
    idOf[i] = id; idMap[id] = i;
  });
  const pick = (a) => (a && a.length ? a.reduce((m, i) => (lastYear[i] > lastYear[m] ? i : m), a[0]) : -1);
  const t = {}; H.t.forEach((x, i) => { t[x[0]] = i; });
  IX = { byName, byName2, idOf, idMap, tIdMap: t, lastYear, firstYear, norm, strip, pick, learned: {} };
  // Champions are exact anchors between the Jolpica ids used in the app and this file.
  Object.keys(H.ds).forEach((y) => {
    const top = H.ds[y].find((x) => x[1] === 1), id = driverChampion(+y); if (top && id) IX.learned[id] = top[0];
    const ct = (H.cs[y] || []).find((x) => x[1] === 1), cid = constructorChampion(+y); if (ct && cid) IX.tIdMap[cid] = ct[0];
  });
  return H;
};

const dIdx = (id) => {
  load();
  if (IX.learned[id] != null) return IX.learned[id];
  return IX.idMap[id] != null ? IX.idMap[id] : -1;
};
// Called whenever a live row names a driver: the Jolpica id is tied to the matching driver in the file by name.
export function learn(id, first, last) {
  if (!id || !last || (IX && IX.learned[id] != null)) return;
  load();
  const a = IX.norm(`${first} ${last}`);
  let i = IX.pick(IX.byName[a]);
  if (i < 0) i = IX.pick(IX.byName2[IX.norm(`${first} ${IX.strip(IX.norm(last))}`)]);
  IX.learned[id] = i; // -1 = not in the file (rookie or reserve): stays live
}
const tIdx = (id) => { load(); return IX.tIdMap[id] != null ? IX.tIdMap[id] : -1; };
export const HISTORY_UPTO = () => load().upTo;
export const hasDriver = (id) => dIdx(id) >= 0;
export const hasTeam = (id) => tIdx(id) >= 0;
export const localYear = (y) => Number(y) <= load().upTo;
export const driverKey = (id) => { const i = dIdx(id); return i >= 0 ? IX.idOf[i] : id; };

const rowsOf = (i) => {
  const out = [];
  Object.keys(H.r).forEach((y) => H.r[y].forEach((rc) => rc[4].forEach((row) => { if (row[0] === i) out.push({ year: +y, rc, row }); })));
  return out;
};
const rowCache = {};
const driverRows = (i) => rowCache[i] || (rowCache[i] = rowsOf(i));
const seasonRowOf = (rc, row) => ({
  round: rc[0], race: rc[1], country: rc[2], date: rc[3], grid: row[2], position: row[3], positionText: row[4], points: row[5], status: row[6], fastest: row[7] === 1,
  teamId: H.t[row[1]][0], team: H.t[row[1]][1],
});
export function localDriverInfo(id) {
  const i = dIdx(id); if (i < 0) return null; const d = H.d[i];
  return { id, name: `${d[1]} ${d[2]}`, number: d[5] != null ? String(d[5]) : undefined, code: d[6], born: d[3] || null, nationality: d[4], url: null };
}
export function localSeasons(id) { const i = dIdx(id); if (i < 0) return null; return [...new Set(driverRows(i).map((x) => x.year))].sort((a, b) => b - a); }
export function localSeasonResults(year, id) {
  const i = dIdx(id); if (i < 0) return null;
  return driverRows(i).filter((x) => x.year === Number(year)).map((x) => seasonRowOf(x.rc, x.row)).sort((a, b) => a.round - b.round);
}
export function localSeasonQuali(year, id) {
  const i = dIdx(id); if (i < 0) return null; const y = String(year);
  const poles = (H.r[y] || []).filter((rc) => rc[5] && rc[5][0] === i).length;
  const q3 = H.q[y]?.[String(i)] || 0;
  return { poles, q3: q3 || (H.q[y] ? 0 : null) };
}
export function localCareer(id) {
  const i = dIdx(id); if (i < 0) return null; const rows = driverRows(i);
  let wins = 0, p = 0, fast = 0, pts = 0;
  rows.forEach(({ row }) => { if (row[4] === '1') wins++; if (['1', '2', '3'].includes(row[4])) p++; if (row[7] === 1) fast++; pts += row[5]; });
  Object.keys(H.sp).forEach((y) => { pts += H.sp[y][String(i)] || 0; });
  let poles = 0; Object.keys(H.r).forEach((y) => H.r[y].forEach((rc) => { if (rc[5] && rc[5][0] === i) poles++; }));
  const years = [...new Set(rows.map((x) => x.year))];
  return { races: rows.length, wins, podiums: p, poles, fastest: fast, points: Math.round(pts * 10) / 10, seasons: years.length, first: years.length ? Math.min(...years) : null, last: years.length ? Math.max(...years) : null };
}
export function localTeamsList(id) {
  const i = dIdx(id); if (i < 0) return null; const out = [];
  [...driverRows(i)].sort((a, b) => a.year - b.year || a.rc[0] - b.rc[0]).forEach(({ year, row }) => {
    const tid = H.t[row[1]][0], last = out[out.length - 1];
    if (last && last.teamId === tid) { last.to = year; last.races++; } else out.push({ teamId: tid, name: H.t[row[1]][1], from: year, to: year, races: 1 });
  });
  return out.reverse();
}
export function localAllDrivers() {
  load();
  return H.d.map((d, i) => ({ driverId: IX.idOf[i], name: `${d[1]} ${d[2]}`, first: d[1], last: d[2], code: d[6], number: d[5] != null ? String(d[5]) : undefined, nationality: d[4], dob: d[3], last_year: IX.lastYear[i], first_year: IX.firstYear[i] }))
    .map((x) => { const id = [...Object.keys(IX.learned)].find((k) => IX.learned[k] === IX.idMap[x.driverId]); return id ? { ...x, driverId: id } : x; });
}
export function localAllTeams() { load(); const seen = {}; return H.t.filter((x) => (seen[x[0]] ? false : (seen[x[0]] = true))).map((x) => ({ teamId: x[0], name: x[1], nationality: x[2] })); }

/* ---- standings of a finished season ---- */
export function localDriverStandings(year) {
  load(); const y = String(year); const list = H.ds[y]; if (!list) return null;
  const wins = {}, team = {};
  (H.r[y] || []).forEach((rc) => rc[4].forEach((row) => { if (row[4] === '1') wins[row[0]] = (wins[row[0]] || 0) + 1; team[row[0]] = row[1]; }));
  const out = [...list].sort((a, b) => a[1] - b[1]).map((s) => {
    const d = H.d[s[0]], t = H.t[team[s[0]]];
    const lid = Object.keys(IX.learned).find((k) => IX.learned[k] === s[0]) || IX.idOf[s[0]];
    return { position: s[1], points: s[2], wins: wins[s[0]] || 0, driverId: lid, name: `${d[1]} ${d[2]}`, first: d[1], last: d[2], code: d[6], permNumber: undefined, teamId: t?.[0], team: t?.[1] };
  });
  return Object.assign(out, { round: (H.r[y] || []).length });
}
export function localConstructorStandings(year) {
  load(); const y = String(year); const list = H.cs[y]; if (!list) return null;
  const wins = {}; (H.r[y] || []).forEach((rc) => rc[4].forEach((row) => { if (row[4] === '1') wins[row[1]] = (wins[row[1]] || 0) + 1; }));
  return Object.assign([...list].sort((a, b) => a[1] - b[1]).map((s) => ({ position: s[1], points: s[2], wins: wins[s[0]] || 0, teamId: H.t[s[0]][0], name: H.t[s[0]][1] })), { round: (H.r[y] || []).length });
}

/* ---- teams ---- */
export function localTeamSeasons(id) {
  const ti = tIdx(id); if (ti < 0) return null; const ys = new Set();
  Object.keys(H.r).forEach((y) => H.r[y].forEach((rc) => rc[4].forEach((row) => { if (row[1] === ti) ys.add(+y); })));
  return [...ys].sort((a, b) => b - a);
}
export function localTeamCareer(id) {
  const ti = tIdx(id); if (ti < 0) return null; let wins = 0, poles = 0; const ys = new Set();
  Object.keys(H.r).forEach((y) => H.r[y].forEach((rc) => { if (rc[5] && rc[5][1] === ti) poles++; rc[4].forEach((row) => { if (row[1] === ti) { ys.add(+y); if (row[4] === '1') wins++; } }); }));
  return { wins, poles, seasons: ys.size, first: ys.size ? Math.min(...ys) : null };
}
export function localTeamSeason(year, id) {
  const ti = tIdx(id); if (ti < 0) return null; const rl = H.r[String(year)] || []; let wins = 0, pod = 0, fast = 0, dnf = 0, poles = 0, doubles = 0; const rounds = [];
  rl.forEach((rc) => {
    const mine = rc[4].filter((row) => row[1] === ti); if (!mine.length) return; rounds.push(rc[0]);
    if (rc[5] && rc[5][1] === ti) poles++;
    const ps = mine.map((r) => r[4]); if (ps.includes('1') && ps.includes('2')) doubles++;
    mine.forEach((r) => { if (r[4] === '1') wins++; if (['1', '2', '3'].includes(r[4])) pod++; if (r[7] === 1) fast++; if (Number.isNaN(Number(r[4]))) dnf++; });
  });
  return { races: rounds.length, wins, podiums: pod, fastest: fast, doubles, dnf, poles };
}
export function localTeamDrivers(year, id) {
  const ti = tIdx(id); if (ti < 0) return null; const seen = {};
  (H.r[String(year)] || []).forEach((rc) => rc[4].forEach((row) => { if (row[1] === ti) seen[row[0]] = (seen[row[0]] || 0) + 1; }));
  return Object.keys(seen).sort((a, b) => seen[b] - seen[a]).slice(0, 4).map((k) => { const d = H.d[k]; return { driverId: IX.idOf[k], name: `${d[1]} ${d[2]}`, first: d[1], last: d[2], number: d[5] != null ? String(d[5]) : undefined, code: d[6] }; });
}
// Points after every round of a finished season (for the season chart).
export function localSeasonPoints(year) {
  load(); const y = String(year); const rl = H.r[y]; if (!rl) return null;
  const drv = {}, team = {};
  rl.forEach((rc) => rc[4].forEach((row) => {
    const d = H.d[row[0]], t = H.t[row[1]];
    const a = drv[row[0]] || (drv[row[0]] = { driverId: IX.idOf[row[0]], first: d[1], last: d[2], by: {} }); a.teamId = t[0]; a.by[rc[0]] = (a.by[rc[0]] || 0) + row[5];
    const b = team[row[1]] || (team[row[1]] = { teamId: t[0], name: t[1], by: {} }); b.by[rc[0]] = (b.by[rc[0]] || 0) + row[5];
  }));
  const rounds = rl.map((rc) => rc[0]);
  const cum = (by) => { let tt = 0; return rounds.map((r) => (tt += by[r] || 0)); };
  const fin = (l) => l.map((o) => ({ ...o, pts: cum(o.by) })).sort((a, b) => b.pts[b.pts.length - 1] - a.pts[a.pts.length - 1]);
  return { rounds: rl.map((rc) => ({ round: rc[0], name: rc[1] })), drivers: fin(Object.values(drv)), teams: fin(Object.values(team)) };
}

// Teammate battles: for every season, the head-to-head against each team-mate over the races they shared (qualifying = grid slot, race = finishing order).
export function localTeammates(id) {
  const i = dIdx(id); if (i < 0) return null; const out = {};
  Object.keys(H.r).forEach((y) => H.r[y].forEach((rc) => {
    const mine = rc[4].find((r) => r[0] === i); if (!mine) return;
    rc[4].forEach((m) => {
      if (m[0] === i || m[1] !== mine[1]) return;
      const k = `${y}:${m[0]}`; const o = (out[k] = out[k] || { year: +y, mate: m[0], team: H.t[mine[1]][1], races: 0, qa: 0, qb: 0, ra: 0, rb: 0, pa: 0, pb: 0 });
      const g = (r) => (r[2] > 0 ? r[2] : 99), p = (r) => (r[3] != null && r[3] > 0 ? r[3] : 99);
      o.races++; if (g(mine) < g(m)) o.qa++; else if (g(m) < g(mine)) o.qb++;
      if (p(mine) < p(m)) o.ra++; else if (p(m) < p(mine)) o.rb++;
      o.pa += mine[5] || 0; o.pb += m[5] || 0;
    });
  }));
  return Object.values(out).filter((o) => o.races >= 3).sort((a, b) => b.year - a.year || b.races - a.races).map((o) => { const d = H.d[o.mate]; return { ...o, mateName: `${d[1]} ${d[2]}`, mateId: IX.idOf[o.mate] }; });
}

// Raw race rows of one season for the what-if replay: [{round, name, rows: [{id, name, team, pos, pts, fast}]}]
export const historyYears = () => Object.keys(load().r).map(Number).sort((a, b) => b - a);
export function sprintPoints(year) {
  load(); const m = H.sp[String(year)]; if (!m) return {}; const out = {};
  Object.keys(m).forEach((k) => { const i = Number(k); out[IX.idOf[i] || String(i)] = m[k]; });
  return out;
}
export function seasonRaw(year) {
  load(); const rs = H.r[year]; if (!rs) return null;
  return rs.map((rc) => ({ round: rc[0], name: rc[1], rows: rc[4].map((r) => ({ id: IX.idOf[r[0]] || String(r[0]), name: `${H.d[r[0]][1]} ${H.d[r[0]][2]}`, team: H.t[r[1]][1], pos: r[3] != null && r[3] > 0 ? r[3] : null, pts: r[5] || 0, fast: r[7] === 1 })) }));
}
// Past winners of a Grand Prix of this name (offline history). Matches by race name, so a race that moved circuits is shown together.
export function raceHistory(name) {
  load(); if (!name) return null; const key = String(name).toLowerCase().trim(); const out = [];
  Object.keys(H.r).forEach((y) => H.r[y].forEach((rc) => { if (String(rc[1]).toLowerCase().trim() !== key) return; const w = rc[4].find((r) => r[4] === '1'); if (!w) return; const pole = rc[5] ? rc[5][0] : null;
    out.push({ year: +y, id: IX.idOf[w[0]] || String(w[0]), name: `${H.d[w[0]][1]} ${H.d[w[0]][2]}`, team: H.t[w[1]][1], grid: w[2], pole: pole != null ? `${H.d[pole][1]} ${H.d[pole][2]}` : null }); }));
  if (!out.length) return null; out.sort((a, b) => b.year - a.year);
  const cnt = {}; out.forEach((x) => { cnt[x.name] = (cnt[x.name] || 0) + 1; }); const top = Object.entries(cnt).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).slice(0, 3).map(([n, c]) => ({ name: n, wins: c }));
  const fromPole = out.filter((x) => x.grid === 1).length;
  return { list: out, top, races: out.length, fromPole, first: out[out.length - 1].year };
}
// One past race as a list of results (real grid, finishing order and status), for the Time machine.
export function raceRowsOf(year, round) {
  load(); const rc = (H.r[year] || []).find((x) => x[0] === round); if (!rc) return null;
  const rows = rc[4].map((r) => ({ id: IX.idOf[r[0]] || String(r[0]), name: `${H.d[r[0]][2]}`, full: `${H.d[r[0]][1]} ${H.d[r[0]][2]}`, code: H.d[r[0]][6] || String(H.d[r[0]][2]).slice(0, 3).toUpperCase(), teamId: H.t[r[1]][0], team: H.t[r[1]][1], grid: r[2] > 0 ? r[2] : 20, pos: r[3] != null && r[3] > 0 ? r[3] : null, posText: r[4], status: r[6] || '', pts: r[5] || 0 }));
  return { round, name: rc[1], country: rc[2], date: rc[3], rows };
}
export const roundsOf = (year) => { load(); return (H.r[year] || []).map((rc) => ({ round: rc[0], name: rc[1], date: rc[3] })); };
// Driver DNA: six 0-100 scores from every race the driver started in the history.
export function dnaOf(id) {
  const i = dIdx(id); if (i < 0) return null; const rows = driverRows(i).map((x) => x.row).filter((r) => r[3] != null);
  if (rows.length < 8) return null;
  const fin = rows.filter((r) => r[3] > 0 && /^\d+$/.test(String(r[4]))), n = rows.length;
  const gr = rows.filter((r) => r[2] > 0); const avgGrid = gr.length ? gr.reduce((a, r) => a + r[2], 0) / gr.length : 12;
  const gain = gr.filter((r) => /^\d+$/.test(String(r[4])) && r[3] > 0); const avgGain = gain.length ? gain.reduce((a, r) => a + (r[2] - r[3]), 0) / gain.length : 0;
  const pos = fin.map((r) => r[3]); const mean = pos.length ? pos.reduce((a, b) => a + b, 0) / pos.length : 15; const sd = pos.length ? Math.sqrt(pos.reduce((a, b) => a + (b - mean) ** 2, 0) / pos.length) : 6;
  const clamp = (v) => Math.max(0, Math.min(100, Math.round(v)));
  return { races: n, axes: [
    ['Qualifying', clamp(100 - (avgGrid - 1) * 6)], ['Racecraft', clamp(50 + avgGain * 10)], ['Consistency', clamp(100 - sd * 7)],
    ['Reliability', clamp((fin.length / n) * 100)], ['Podiums', clamp((rows.filter((r) => r[3] > 0 && r[3] <= 3 && /^\d+$/.test(String(r[4]))).length / n) * 170)], ['Fast laps', clamp((rows.filter((r) => r[7] === 1).length / n) * 500)] ] };
}

// Every team a driver raced for, as stints (consecutive seasons with one team), with wins and the seasons they won the title.
export function driverTimeline(id) {
  const i = dIdx(id); if (i < 0) return null; const rows = driverRows(i); if (!rows.length) return null;
  const byYear = {}; rows.forEach(({ year, row }) => { const y = (byYear[year] = byYear[year] || {}); const t = H.t[row[1]]; const k = t[0]; y[k] = y[k] || { teamId: k, team: t[1], races: 0, wins: 0 }; y[k].races++; if (row[4] === '1') y[k].wins++; });
  const stints = []; Object.keys(byYear).map(Number).sort((a, b) => a - b).forEach((y) => { const main = Object.values(byYear[y]).sort((a, b) => b.races - a.races)[0]; const last = stints[stints.length - 1];
    if (last && last.teamId === main.teamId && y - last.to <= 1) { last.to = y; last.races += main.races; last.wins += main.wins; } else stints.push({ teamId: main.teamId, team: main.team, from: y, to: y, races: main.races, wins: main.wins }); });
  let titles = []; try { titles = driverChampionYears(id).filter((y) => byYear[y]); } catch {}
  return { stints, titles, from: stints[0].from, to: stints[stints.length - 1].to };
}
export function lastTeamOf(id) { const i = dIdx(id); if (i < 0) return null; const rows = driverRows(i); if (!rows.length) return null; const r = rows.reduce((a, b) => (b.year >= a.year ? b : a)); return { teamId: H.t[r.row[1]][0], team: H.t[r.row[1]][1] }; }
// Every result line of a past season with its status text (for the reliability report).
export function localSeasonStatuses(year) {
  load(); const rcs = H.r[year]; if (!rcs) return null;
  return rcs.flatMap((rc) => rc[4].map((r) => ({ round: rc[0], race: rc[1], teamId: H.t[r[1]][0], team: H.t[r[1]][1], driverId: IX.idOf[r[0]] || String(r[0]), last: H.d[r[0]][2], status: r[6] || '', finished: /^(Finished|\+\d+ Laps?)$/i.test(r[6] || '') })));
}

// Every team that ever appears in the history: first and last season, race starts, wins and titles (for the team family trees).
let ERAS = null;
export function teamEras() {
  if (ERAS) return ERAS; load(); const m = {};
  Object.keys(H.r).forEach((y) => H.r[y].forEach((rc) => rc[4].forEach((r) => { const t = H.t[r[1]]; const e = (m[t[0]] = m[t[0]] || { id: t[0], name: t[1], first: +y, last: +y, starts: 0, wins: 0, names: {} }); e.first = Math.min(e.first, +y); e.last = Math.max(e.last, +y); e.starts++; if (r[4] === '1') e.wins++; e.names[t[1]] = (e.names[t[1]] || 0) + 1; })));
  Object.values(m).forEach((e) => { let t = 0; try { t = constructorChampionYears(e.id).length; } catch {} e.titles = t; e.name = Object.entries(e.names).sort((a, b) => b[1] - a[1])[0][0]; delete e.names; });
  ERAS = m; return m;
}

// Races held and drivers born on a calendar day (month-day), for the "on this day" stat.
export function onThisDay(md) {
  load(); const races = [], births = [];
  Object.keys(H.r).forEach((y) => H.r[y].forEach((rc) => { if (String(rc[3]).slice(5) === md) { const w = rc[4].find((r) => r[4] === '1'); if (w) races.push({ year: +y, name: rc[1], winner: `${H.d[w[0]][1]} ${H.d[w[0]][2]}` }); } }));
  H.d.forEach((d) => { if (d && String(d[3] || '').slice(5) === md) births.push({ name: `${d[1]} ${d[2]}`, year: Number(String(d[3]).slice(0, 4)) }); });
  return { races, births };
}

// Regular race seats of a season: for each team the two drivers with the most starts (for Build the grid).
export function seasonGrid(year) {
  load(); const cnt = {};
  (H.r[String(year)] || []).forEach((rc) => rc[4].forEach((r) => { const c = (cnt[r[1]] ||= {}); c[r[0]] = (c[r[0]] || 0) + 1; }));
  return Object.keys(cnt).map((t) => ({ teamId: H.t[t][0], name: H.t[t][1], drivers: Object.entries(cnt[t]).sort((a, b) => b[1] - a[1] || a[0] - b[0]).slice(0, 2).map(([k]) => ({ driverId: IX.idOf[k], name: `${H.d[k][1]} ${H.d[k][2]}`, last: H.d[k][2] })) })).sort((a, b) => a.name.localeCompare(b.name));
}
export function firstWinOf(id) { const i = dIdx(id); if (i < 0) return null; let best = null; driverRows(i).forEach(({ year, rc, row }) => { if (row[4] === '1' && (!best || String(rc[3]) < best.date)) best = { year, date: String(rc[3]), name: rc[1] }; }); return best; }
export function dobOf(id) { const i = dIdx(id); return i < 0 ? null : H.d[i][3] || null; }
let _titles = null;
// Titles per driver index, counted once (it used to be recounted for every driver, which made the first stats screen slow on a phone).
function titleMap() { if (_titles) return _titles; load(); _titles = {}; historyYears().forEach((y) => { const c = driverChampion(y); const i = c ? dIdx(c) : -1; if (i >= 0) _titles[i] = (_titles[i] || 0) + 1; }); return _titles; }
export function titlesOf(id) { load(); const i = dIdx(id); if (i < 0) return 0; return titleMap()[i] || 0; }

// Passing by race: for every Grand Prix name, the average number of places finishers moved between grid and flag, and how often pole won.
// Counts classified finishers who started on the grid. Pit stops and strategy move cars too, so this is "position change", not a count of overtakes.
export function passingByRace(sinceYear) {
  load(); const by = {};
  Object.keys(H.r).forEach((y) => { if (+y < sinceYear) return; H.r[y].forEach((rc) => {
    const o = (by[rc[1]] ||= { name: rc[1], races: 0, moved: 0, n: 0, poleWins: 0, poleRaces: 0, winnerGain: 0, lastYear: 0 });
    o.races++; o.lastYear = Math.max(o.lastYear, +y);
    rc[4].forEach((r) => { if (r[2] > 0 && r[3] > 0 && /^\d+$/.test(String(r[4]))) { o.moved += Math.abs(r[2] - r[3]); o.n++; } });
    const w = rc[4].find((r) => r[4] === '1'); const p = rc[4].find((r) => r[2] === 1);
    if (w && w[2] > 0) o.winnerGain += w[2] - 1; if (p && w) { o.poleRaces++; if (p === w) o.poleWins++; }
  }); });
  return Object.values(by).filter((o) => o.n >= 40).map((o) => ({ name: o.name, races: o.races, avgMoved: o.moved / o.n, poleRate: o.poleRaces ? o.poleWins / o.poleRaces : 0, avgWinnerStart: 1 + o.winnerGain / o.races, lastYear: o.lastYear }));
}
// One season in numbers, for comparing two seasons side by side.
export function seasonFacts(year) {
  load(); const y = String(year); const rl = H.r[y]; if (!rl || !rl.length) return null;
  const wins = {}, teamWins = {}; let starts = 0, fin = 0, poles = {}, cars = 0;
  rl.forEach((rc) => { cars += rc[4].length; rc[4].forEach((r) => { starts++; if (/^\d+$/.test(String(r[4]))) fin++; if (r[4] === '1') { wins[r[0]] = (wins[r[0]] || 0) + 1; teamWins[r[1]] = (teamWins[r[1]] || 0) + 1; } }); const p = rc[4].find((r) => r[2] === 1); if (p) poles[p[0]] = (poles[p[0]] || 0) + 1; });
  const top = (m, names) => { const e = Object.entries(m).sort((a, b) => b[1] - a[1])[0]; return e ? { name: names(e[0]), n: e[1] } : null; };
  const std = (H.ds[y] || []).slice().sort((a, b) => a[1] - b[1]);
  const nm = (k) => `${H.d[k][1]} ${H.d[k][2]}`;
  return { year: +year, races: rl.length, winners: Object.keys(wins).length, avgCars: cars / rl.length, finishRate: fin / starts,
    mostWins: top(wins, nm), mostTeamWins: top(teamWins, (k) => H.t[k][1]), mostPoles: top(poles, nm),
    champion: std[0] ? nm(std[0][0]) : null, champPts: std[0] ? std[0][2] : null, secondPts: std[1] ? std[1][2] : null, thirdPts: std[2] ? std[2][2] : null };
}

// A season as a story: who led the title race and when, the best comeback win, podium table and race winners. Offline.
export function seasonStory(year) {
  load(); const y = String(year); const rl = H.r[y]; const sp = localSeasonPoints(year); if (!rl || !rl.length || !sp) return null;
  const leaders = sp.rounds.map((_, k) => { let best = null; sp.drivers.forEach((d) => { if (!best || (d.pts[k] || 0) > (best.pts[k] || 0)) best = d; }); return best; });
  const nm = (d) => `${d.first} ${d.last}`; const final = leaders[leaders.length - 1];
  let changes = 0; for (let k = 1; k < leaders.length; k++) if (leaders[k] !== leaders[k - 1]) changes++;
  let forGood = 0; for (let k = leaders.length - 1; k >= 0; k--) { if (leaders[k] !== final) { forGood = sp.rounds[k + 1].round; break; } }
  const winners = rl.map((rc) => { const w = rc[4].find((r) => r[4] === '1'); return { round: rc[0], name: rc[1], winner: w ? `${H.d[w[0]][1]} ${H.d[w[0]][2]}` : '-', grid: w ? w[2] : 0, team: w ? H.t[w[1]][1] : '' }; });
  const comeback = winners.filter((w) => w.grid > 0).sort((a, b) => b.grid - a.grid)[0];
  const pod = {}; rl.forEach((rc) => rc[4].forEach((r) => { if (['1', '2', '3'].includes(r[4])) pod[r[0]] = (pod[r[0]] || 0) + 1; }));
  const topPod = Object.entries(pod).sort((a, b) => b[1] - a[1])[0];
  const lead = leaders.map((d) => nm(d)); const leadersSeen = [...new Set(lead)];
  return { year: +year, champion: nm(final), leadChanges: changes, leaderForGoodAfter: forGood, leadersSeen, winners, comeback: comeback && comeback.grid > 1 ? comeback : null, mostPodiums: topPod ? { name: `${H.d[topPod[0]][1]} ${H.d[topPod[0]][2]}`, n: topPod[1] } : null };
}
// Drivers whose first season was `year` (with their debut race) and whose last season in the history was `year` (with their last race and career wins).
export function debutsOf(year) {
  load(); const up = H.upTo; const deb = [], far = [];
  H.d.forEach((d, i) => {
    const fy = IX.firstYear[i], ly = IX.lastYear[i]; if (fy !== year && ly !== year) return; const rows = driverRows(i);
    const nameOf = `${d[1]} ${d[2]}`;
    if (fy === year) { const f = rows.filter((x) => x.year === year).sort((a, b) => a.rc[0] - b.rc[0])[0]; if (f) deb.push({ id: IX.idOf[i], name: nameOf, nat: d[4], round: f.rc[0], race: f.rc[1], team: H.t[f.row[1]][1], grid: f.row[2], pos: f.row[4], dnf: !/^\d+$/.test(String(f.row[4])) }); }
    if (ly === year && year < up) { const l = rows.filter((x) => x.year === year).sort((a, b) => b.rc[0] - a.rc[0])[0]; const wins = rows.filter((x) => x.row[4] === '1').length; if (l) far.push({ id: IX.idOf[i], name: nameOf, nat: d[4], round: l.rc[0], race: l.rc[1], team: H.t[l.row[1]][1], starts: rows.length, wins }); }
  });
  deb.sort((a, b) => a.round - b.round || a.name.localeCompare(b.name)); far.sort((a, b) => b.wins - a.wins || b.starts - a.starts);
  return { debuts: deb, farewells: far, upTo: up };
}

// Home Grand Prix record of every driver whose country hosted a race. The Indianapolis 500 rounds of 1950 to 1960 are not counted as an American home race.
const HOME = { British: 'UK', American: 'USA', Italian: 'Italy', French: 'France', Belgian: 'Belgium', German: 'Germany', Spanish: 'Spain', Dutch: 'Netherlands', Argentine: 'Argentina', Portuguese: 'Portugal', Moroccan: 'Morocco', 'South African': 'South Africa', Mexican: 'Mexico', Austrian: 'Austria', Canadian: 'Canada', Brazilian: 'Brazil', Swedish: 'Sweden', Japanese: 'Japan', Australian: 'Australia', Hungarian: 'Hungary', Malaysian: 'Malaysia', Chinese: 'China', Swiss: 'Switzerland', 'Monégasque': 'Monaco', Russian: 'Russia' };
export function homeRecords() {
  load(); const out = {};
  Object.keys(H.r).forEach((y) => H.r[y].forEach((rc) => {
    if (/indianapolis 500/i.test(rc[1])) return;
    rc[4].forEach((r) => { const d = H.d[r[0]]; if (HOME[d[4]] !== rc[2]) return;
      const o = (out[r[0]] ||= { id: IX.idOf[r[0]], name: `${d[1]} ${d[2]}`, country: rc[2], starts: 0, wins: 0, podiums: 0, poles: 0, best: 99, bestAt: '', total: 0 });
      o.starts++; if (r[4] === '1') o.wins++; if (['1', '2', '3'].includes(r[4])) o.podiums++; if (r[2] === 1) o.poles++;
      const pos = /^\d+$/.test(String(r[4])) ? +r[4] : 99; if (pos < o.best) { o.best = pos; o.bestAt = `${y} ${rc[1]}`; } });
  }));
  Object.keys(out).forEach((k) => { const o = out[k]; const tot = driverRows(+k).length; o.total = tot; });
  return Object.values(out);
}
// Pairs of drivers who shared podiums, 1-2 finishes and front rows. `since` limits the years. Team-mate counts say how often both drove for the same team.
export function podiumPairs(since) {
  load(); const pod = {}, one2 = {}, front = {};
  const add = (m, a, b, same) => { const k = a < b ? `${a}|${b}` : `${b}|${a}`; const o = (m[k] ||= { a: Math.min(a, b), b: Math.max(a, b), n: 0, mates: 0 }); o.n++; if (same) o.mates++; };
  Object.keys(H.r).forEach((y) => { if (+y < since) return; H.r[y].forEach((rc) => {
    const top = rc[4].filter((r) => ['1', '2', '3'].includes(String(r[4]))).sort((a, b) => +a[4] - +b[4]);
    for (let i = 0; i < top.length; i++) for (let j = i + 1; j < top.length; j++) add(pod, top[i][0], top[j][0], top[i][1] === top[j][1]);
    if (top.length >= 2 && top[0][4] === '1' && top[1][4] === '2') add(one2, top[0][0], top[1][0], top[0][1] === top[1][1]);
    const fr = rc[4].filter((r) => r[2] === 1 || r[2] === 2); if (fr.length === 2) add(front, fr[0][0], fr[1][0], fr[0][1] === fr[1][1]);
  }); });
  const nm = (i) => `${H.d[i][1]} ${H.d[i][2]}`;
  const fin = (m) => Object.values(m).sort((x, y) => y.n - x.n || x.mates - y.mates).slice(0, 15).map((o) => ({ a: nm(o.a), b: nm(o.b), n: o.n, mates: o.mates }));
  return { podium: fin(pod), onetwo: fin(one2), front: fin(front) };
}
// Everything the Connections puzzle needs about a driver, built once.
let META = null;
export function driversMeta() {
  if (META) return META; load();
  // One pass over every result row. (It used to rescan every race for every driver, about 20 million steps, which froze a phone for many seconds.)
  const st = {}; Object.keys(H.r).forEach((y) => H.r[y].forEach((rc) => rc[4].forEach((r) => { const o = (st[r[0]] ||= { n: 0, teams: new Set() }); o.n++; o.teams.add(H.t[r[1]][0]); })));
  const tm = titleMap();
  META = H.d.map((d, i) => { const o = st[i]; if (!o || o.n < 20) return null;
    return { id: IX.idOf[i], name: `${d[1]} ${d[2]}`, last: d[2], nat: d[4], races: o.n, first: IX.firstYear[i], lastYear: IX.lastYear[i], teams: o.teams, champ: (tm[i] || 0) > 0 }; }).filter(Boolean);
  return META;
}
export function teamNameOf(teamId) { load(); const t = H.t.find((x) => x[0] === teamId); return t ? t[1] : teamId; }

// Three-letter timing code for a driver, from the history when the name is known, otherwise the first three letters of the surname.
let CODES = null;
export function codeOf(first, last) {
  if (!CODES) { load(); CODES = {}; H.d.forEach((d, i) => { if (d[6]) CODES[IX.norm(`${d[1]} ${d[2]}`)] = d[6]; }); }
  const k = IX.norm(`${first || ''} ${last || ''}`); if (CODES[k]) return CODES[k];
  return IX.norm(String(last || '').split(' ').pop()).replace(/[^a-z]/g, '').slice(0, 3).toUpperCase();
}

// Biggest comebacks: classified finishers who won or stood on the podium from far back on the grid. Pit-lane starts (grid 0) are left out because the slot is not a position.
export function comebacks(since) {
  load(); const wins = [], pods = [];
  Object.keys(H.r).forEach((y) => { if (+y < since) return; H.r[y].forEach((rc) => /indianapolis 500/i.test(rc[1]) ? null : rc[4].forEach((r) => {
    if (!(r[2] > 0) || !['1', '2', '3'].includes(String(r[4]))) return;
    const o = { year: +y, race: rc[1], name: `${H.d[r[0]][1]} ${H.d[r[0]][2]}`, team: H.t[r[1]][1], grid: r[2], pos: +r[4], gain: r[2] - +r[4], cars: rc[4].length };
    pods.push(o); if (r[4] === '1') wins.push(o);
  })); });
  const top = (a) => a.sort((x, y) => y.grid - x.grid || y.gain - x.gain || y.year - x.year).slice(0, 25);
  return { wins: top(wins), podiums: top(pods) };
}

// Finishing-position counts per driver over the first `upto` races of a season, by driverId: [wins, 2nds, 3rds, ...].
// Used for the official championship tie-break (most wins, then most second places, and so on).
export function finishCountsAt(year, upto) {
  load(); const rl = H.r[String(year)]; if (!rl) return null; const out = {};
  rl.slice(0, upto).forEach((rc) => rc[4].forEach((r) => { const p = /^\d+$/.test(String(r[4])) ? +r[4] : 0; if (!p) return; const id = IX.idOf[r[0]]; if (!id) return; const a = (out[id] ||= []); a[p - 1] = (a[p - 1] || 0) + 1; }));
  return out;
}

// Longest runs of consecutive race entries with a win, a podium or points, per driver, from the offline history.
// A run is broken by any race the driver entered without the result (a race they skip does not break it). `active` = still running at the last race in the file.
export function streakBoard() {
  load(); const per = {}; const years = Object.keys(H.r).map(Number).sort((a, b) => a - b); let lastKey = null;
  years.forEach((y) => H.r[String(y)].forEach((rc) => { lastKey = `${y}-${rc[0]}`; rc[4].forEach((r) => { (per[r[0]] ||= []).push({ y, rd: rc[0], pos: /^\d+$/.test(String(r[4])) ? +r[4] : 99, pts: Number(r[5]) || 0, key: `${y}-${rc[0]}` }); }); }));
  const kinds = { win: (x) => x.pos === 1, podium: (x) => x.pos <= 3, points: (x) => x.pts > 0 };
  const out = { win: [], podium: [], points: [] };
  Object.keys(per).forEach((k) => { const L = per[k]; const d = H.d[k]; if (!d) return;
    Object.keys(kinds).forEach((kind) => { let run = 0, best = null, start = 0;
      L.forEach((x, i) => { if (kinds[kind](x)) { if (!run) start = i; run++; if (!best || run > best.len) best = { len: run, s: start, e: i }; } else run = 0; });
      if (!best) return; const cur = run > 0 && L[L.length - 1].key === lastKey ? run : 0;
      out[kind].push({ id: IX.idOf[k], name: `${d[1]} ${d[2]}`, len: best.len, from: `${L[best.s].y} R${L[best.s].rd}`, to: `${L[best.e].y} R${L[best.e].rd}`, current: cur });
    }); });
  Object.keys(out).forEach((kind) => out[kind].sort((a, b) => b.len - a.len || a.name.localeCompare(b.name)));
  return { rows: out, upTo: lastKey };
}

// Results grouped by power unit supplier. `map` is data/engines.js. Titles: the champion's car at the time (most-used team that year).
export function engineBoard(map, fromYear, toYear) {
  load(); const supplierOf = (tid, y) => Object.keys(map).find((s) => map[s].some(([t, a, b]) => t === tid && y >= a && y <= b));
  const out = {}; Object.keys(map).forEach((s) => { out[s] = { name: s, entries: 0, wins: 0, podiums: 0, poles: 0, driverTitles: 0, constructorTitles: 0, teams: {}, seasons: new Set(), unmapped: 0 }; });
  const champTeam = (y) => { const id = driverChampion(y); const ci = id ? dIdx(id) : -1; if (ci < 0) return null; const c = {}; (H.r[String(y)] || []).forEach((rc) => rc[4].forEach((r) => { if (r[0] === ci) { const t = H.t[r[1]][0]; c[t] = (c[t] || 0) + 1; } })); const e = Object.entries(c).sort((a, b) => b[1] - a[1])[0]; return e ? e[0] : null; };
  for (let y = fromYear; y <= toYear; y++) {
    const rl = H.r[String(y)]; if (!rl) continue;
    rl.forEach((rc) => rc[4].forEach((r) => { const tid = H.t[r[1]][0]; const s = supplierOf(tid, y); if (!s) { out[Object.keys(out)[0]].unmapped++; return; } const o = out[s]; o.entries++; o.seasons.add(y); (o.teams[y] ||= new Set()).add(tid); if (r[4] === '1') o.wins++; if (['1', '2', '3'].includes(String(r[4]))) o.podiums++; if (r[2] === 1) o.poles++; }));
    const ct = champTeam(y); const cs = ct && supplierOf(ct, y); if (cs) out[cs].driverTitles++;
    const cc = constructorChampion(y); const ccs = cc && supplierOf(cc, y); if (ccs) out[ccs].constructorTitles++;
  }
  return Object.values(out).map((o) => ({ ...o, seasons: [...o.seasons].sort(), teams: Object.fromEntries(Object.entries(o.teams).map(([y, v]) => [y, [...v]])) })).sort((a, b) => b.wins - a.wins);
}

// Pole to win conversion from the offline history. A "pole" is the car on P1 of the starting grid (a grid penalty can make this differ from official pole).
export function poleConversion() {
  load(); const d = {}, t = {}, c = {}, y = {}; let poles = 0, conv = 0;
  Object.keys(H.r).forEach((yr) => H.r[yr].forEach((rc) => {
    const p = rc[4].find((r) => r[2] === 1); if (!p) return; const win = p[4] === '1'; poles++; if (win) conv++;
    const dk = IX.idOf[p[0]], tk = H.t[p[1]][1]; const dn = `${H.d[p[0]][1]} ${H.d[p[0]][2]}`;
    const bump = (m, k, name) => { const o = (m[k] ||= { name, poles: 0, wins: 0 }); o.poles++; if (win) o.wins++; };
    bump(d, dk, dn); bump(t, tk, tk); bump(c, rc[1], rc[1]); bump(y, yr, yr);
  }));
  const fin = (m, min) => Object.values(m).filter((o) => o.poles >= min).map((o) => ({ ...o, rate: o.wins / o.poles })).sort((a, b) => b.rate - a.rate || b.poles - a.poles);
  return { poles, conv, drivers: fin(d, 10), teams: fin(t, 20), circuits: fin(c, 15), years: Object.values(y).map((o) => ({ ...o, rate: o.wins / o.poles })).sort((a, b) => +b.name - +a.name) };
}

// Everything the race preview card shows for one Grand Prix name: recent winners, who wins here most, how often pole wins, and how given drivers did here.
export function circuitSummary(raceName, driverIds = []) {
  load(); const nm = String(raceName || '').toLowerCase(); const races = [];
  Object.keys(H.r).sort((a, b) => b - a).forEach((y) => H.r[y].forEach((rc) => { if (String(rc[1]).toLowerCase() === nm) races.push({ y: +y, rc }); }));
  if (!races.length) return null;
  const nameOf = (k) => `${H.d[k][1]} ${H.d[k][2]}`; const wins = {}; let poles = 0, conv = 0;
  const recent = races.slice(0, 5).map(({ y, rc }) => { const w = rc[4].find((r) => r[4] === '1'); return { year: y, winner: w ? nameOf(w[0]) : '-', team: w ? H.t[w[1]][1] : '' }; });
  races.forEach(({ rc }) => { const w = rc[4].find((r) => r[4] === '1'); if (w) wins[w[0]] = (wins[w[0]] || 0) + 1; const p = rc[4].find((r) => r[2] === 1); if (p) { poles++; if (p[4] === '1') conv++; } });
  const top = Object.entries(wins).sort((a, b) => b[1] - a[1] || 0).slice(0, 3).map(([k, n]) => ({ name: nameOf(k), n }));
  const favs = driverIds.map((id) => { const i = dIdx(id); if (i < 0) return null; let starts = 0, w = 0, pod = 0, best = 99;
    races.forEach(({ rc }) => { const r = rc[4].find((x) => x[0] === i); if (!r) return; starts++; const p = /^\d+$/.test(String(r[4])) ? +r[4] : 99; if (p === 1) w++; if (p <= 3) pod++; if (p < best) best = p; });
    return starts ? { id, name: nameOf(i), starts, wins: w, podiums: pod, best: best === 99 ? null : best } : null; }).filter(Boolean);
  return { editions: races.length, first: races[races.length - 1].y, last: races[0].y, recent, top, poleWinRate: poles ? conv / poles : null, favs };
}

// Per-driver race lists in order (entered races only): [{ y, rd, pos, grid }]. pos 99 = not classified. Cached.
let _per = null;
function perDriver() {
  if (_per) return _per; load(); const per = {}; const years = Object.keys(H.r).map(Number).sort((a, b) => a - b); let last = null;
  years.forEach((y) => H.r[String(y)].forEach((rc) => { last = `${y}-${rc[0]}`; rc[4].forEach((r) => { (per[r[0]] ||= []).push({ y, rd: rc[0], pos: /^\d+$/.test(String(r[4])) ? +r[4] : 99, grid: r[2], t: r[1], key: last }); }); }));
  _per = { per, last }; return _per;
}
export const nameOfIdx = (k) => `${H.d[k][1]} ${H.d[k][2]}`;

// Win droughts. `between`: longest run of races entered between two wins. `waits`: races entered before the first win. `now`: running droughts of drivers still racing at the end of the history.
export function winDroughts() {
  const { per, last } = perDriver(); const between = [], waits = [], now = [];
  Object.keys(per).forEach((k) => { const L = per[k]; const w = []; L.forEach((x, i) => { if (x.pos === 1) w.push(i); }); if (!w.length) return; const name = nameOfIdx(k); const active = L[L.length - 1].key === last;
    waits.push({ name, n: w[0], to: `${L[w[0]].y} R${L[w[0]].rd}` });
    let best = null; for (let i = 1; i < w.length; i++) { const g = w[i] - w[i - 1] - 1; if (!best || g > best.n) best = { name, n: g, from: `${L[w[i - 1]].y} R${L[w[i - 1]].rd}`, to: `${L[w[i]].y} R${L[w[i]].rd}` }; }
    if (best && best.n > 0) between.push(best);
    if (active) { const since = L.length - 1 - w[w.length - 1]; if (since > 0) now.push({ name, n: since, from: `${L[w[w.length - 1]].y} R${L[w[w.length - 1]].rd}` }); } });
  const sort = (a) => a.sort((x, y) => y.n - x.n || x.name.localeCompare(y.name));
  return { between: sort(between).slice(0, 25), waits: sort(waits).slice(0, 25), now: sort(now).slice(0, 25) };
}

// Drivers who never won (most podiums, most starts) and drivers with exactly one win.
export function winless() {
  const { per } = perDriver(); const never = [], one = [];
  Object.keys(per).forEach((k) => { const L = per[k]; const wins = L.filter((x) => x.pos === 1).length; const pod = L.filter((x) => x.pos <= 3).length; const name = nameOfIdx(k); const yrs = `${L[0].y}${L[L.length - 1].y !== L[0].y ? `-${L[L.length - 1].y}` : ''}`;
    if (!wins && L.length >= 40) never.push({ name, starts: L.length, podiums: pod, best: Math.min(...L.map((x) => x.pos)), yrs });
    if (wins === 1) one.push({ name, starts: L.length, podiums: pod, yrs, win: `${L.find((x) => x.pos === 1).y}` }); });
  never.sort((a, b) => b.podiums - a.podiums || b.starts - a.starts); one.sort((a, b) => b.starts - a.starts);
  return { never: never.slice(0, 25), one: one.slice(0, 25), oneCount: one.length };
}

// Average places gained from the grid to the flag, over races where the driver started on the grid (grid 1+) and was classified. Min 50 such races (drivers), 100 (teams), 15 (seasons).
export function placesGained() {
  const { per } = perDriver(); const d = [], t = {}, y = {};
  Object.keys(per).forEach((k) => { let n = 0, s = 0; per[k].forEach((x) => { if (x.grid >= 1 && x.pos < 99) { const g = x.grid - x.pos; n++; s += g; const tn = H.t[x.t][1]; (t[tn] ||= { name: tn, n: 0, s: 0 }); t[tn].n++; t[tn].s += g; (y[x.y] ||= { name: String(x.y), n: 0, s: 0 }); y[x.y].n++; y[x.y].s += g; } });
    if (n >= 50) d.push({ name: nameOfIdx(k), n, avg: s / n }); });
  const fin = (m, min) => Object.values(m).filter((o) => o.n >= min).map((o) => ({ name: o.name, n: o.n, avg: o.s / o.n }));
  const by = (a) => a.sort((x, z) => z.avg - x.avg);
  return { drivers: by(d), teams: by(fin(t, 100)), years: fin(y, 15).sort((a, b) => +b.name - +a.name) };
}

// Career numbers for the games, by driver id.
export function careerStats(id) {
  const i = dIdx(id); if (i < 0) return null; const L = (perDriver().per[i]) || [];
  return { wins: L.filter((x) => x.pos === 1).length, podiums: L.filter((x) => x.pos <= 3).length, starts: L.length, poles: L.filter((x) => x.grid === 1).length, titles: titlesOf(id) };
}
// Team names in the order a driver first raced for them (consecutive duplicates removed), and the team with most starts.
export function careerTeams(id) {
  const i = dIdx(id); if (i < 0) return null; const L = (perDriver().per[i]) || []; const seq = [], cnt = {};
  L.forEach((x) => { const n = H.t[x.t][1]; cnt[n] = (cnt[n] || 0) + 1; if (seq[seq.length - 1] !== n) seq.push(n); });
  const main = Object.entries(cnt).sort((a, b) => b[1] - a[1])[0]; return { seq, main: main ? main[0] : '', mainStarts: main ? main[1] : 0 };
}

// How often each starting slot has turned into a win or a podium, by era. Pit-lane starts (grid 0) are left out.
export function gridSlotOdds() {
  load(); const eras = [['All time', 1950, 2100], ['1950 to 1979', 1950, 1979], ['1980 to 1999', 1980, 1999], ['2000 to 2013', 2000, 2013], ['2014 to now', 2014, 2100]];
  return eras.map(([label, a, b]) => { const slots = Array.from({ length: 24 }, (_, i) => ({ slot: i + 1, n: 0, wins: 0, podiums: 0 }));
    Object.keys(H.r).filter((y) => +y >= a && +y <= b).forEach((y) => H.r[y].forEach((rc) => rc[4].forEach((r) => { const g = r[2]; if (!(g >= 1 && g <= 24)) return; const s = slots[g - 1]; s.n++; const p = String(r[4]); if (p === '1') s.wins++; if (p === '1' || p === '2' || p === '3') s.podiums++; })));
    return { label, slots: slots.filter((s) => s.n >= 30) }; });
}

// Driver pairings per team and season: the two highest scorers for the team. `share` = their combined points as a fraction of all points scored that season,
// which makes different points systems comparable. Race points only as stored in the history.
export function lineupStrength() {
  load(); const out = [];
  Object.keys(H.r).forEach((y) => { const team = {}; let total = 0;
    H.r[y].forEach((rc) => rc[4].forEach((r) => { const pts = Number(r[5]) || 0; total += pts; const t = (team[r[1]] ||= {}); t[r[0]] = (t[r[0]] || 0) + pts; }));
    if (!total) return;
    Object.keys(team).forEach((tk) => { const ds = Object.entries(team[tk]).sort((a, b) => b[1] - a[1]); if (ds.length < 2 || ds[0][1] + ds[1][1] <= 0) return; const [a, b] = ds; const comb = a[1] + b[1];
      out.push({ year: +y, team: H.t[tk][1], a: nameOfIdx(a[0]), b: nameOfIdx(b[0]), pa: a[1], pb: b[1], comb, share: comb / total, lop: (a[1] - b[1]) / comb }); }); });
  const strongest = [...out].sort((x, y) => y.share - x.share).slice(0, 25);
  const weakest = out.filter((x) => x.share > 0.01).sort((x, y) => x.share - y.share).slice(0, 25);
  const lopsided = out.filter((x) => x.share >= 0.05).sort((x, y) => y.lop - x.lop).slice(0, 25);
  const matched = out.filter((x) => x.share >= 0.08).sort((x, y) => x.lop - y.lop).slice(0, 25);
  return { strongest, lopsided, matched, weakest };
}

// Every championship: champion, points, margin, wins, and (1991 to 2020 only) the round the title was mathematically won.
// Clinch maths: after round k the champion's lead over the best other driver must be more than the most points the rest of the season can give (no dropped scores, no sprints in that range; 2014 double points at the last race counted).
const maxPerRace = (y) => (y <= 2009 ? 10 : y <= 2018 ? 25 : 26);
export function titleHistory() {
  load(); const rows = [];
  Object.keys(H.ds).map(Number).sort((a, b) => a - b).forEach((y) => { const id = driverChampion(y); const ci = id ? dIdx(id) : -1; if (ci < 0) return;
    const ds = [...H.ds[String(y)]].sort((a, b) => a[1] - b[1]); const top = ds[0], sec = ds[1]; if (!top || top[0] !== ci || !sec) return;
    const races = H.r[String(y)] || []; let wins = 0; const t = {}; races.forEach((rc) => rc[4].forEach((r) => { if (r[0] === ci) { if (r[4] === '1') wins++; t[r[1]] = (t[r[1]] || 0) + 1; } }));
    const tk = Object.entries(t).sort((a, b) => b[1] - a[1])[0];
    let clinch = null;
    if (y >= 1991 && y <= 2020 && races.length) { const cum = {}; for (let k = 0; k < races.length; k++) { races[k][4].forEach((r) => { cum[r[0]] = (cum[r[0]] || 0) + (Number(r[5]) || 0); }); const mine = cum[ci] || 0; const other = Math.max(0, ...Object.keys(cum).filter((x) => +x !== ci).map((x) => cum[x])); let rest = 0; for (let j = k + 1; j < races.length; j++) rest += y === 2014 && j === races.length - 1 ? 50 : maxPerRace(y); if (mine - other > rest) { clinch = { round: k + 1, of: races.length, name: races[k][1] }; break; } } }
    rows.push({ year: y, name: nameOfIdx(ci), team: tk ? H.t[tk[0]][1] : '', pts: top[2], second: nameOfIdx(sec[0]), secPts: sec[2], margin: top[2] - sec[2], pct: (top[2] - sec[2]) / top[2], wins, rounds: races.length, clinch }); });
  const closest = [...rows].sort((a, b) => a.pct - b.pct).slice(0, 15), biggest = [...rows].sort((a, b) => b.pct - a.pct).slice(0, 15);
  const early = rows.filter((r) => r.clinch).sort((a, b) => (b.clinch.of - b.clinch.round) - (a.clinch.of - a.clinch.round) || b.pct - a.pct).slice(0, 15);
  const lastRace = rows.filter((r) => r.clinch && r.clinch.round === r.clinch.of).sort((a, b) => b.year - a.year);
  const fewWins = [...rows].filter((r) => r.rounds >= 8).sort((a, b) => a.wins - b.wins || a.year - b.year).slice(0, 15);
  return { rows: rows.sort((a, b) => b.year - a.year), closest, biggest, early, lastRace, fewWins };
}

const ageParts = (days) => { const y = Math.floor(days / 365.25); return { y, d: Math.floor(days - y * 365.25), days }; };
// Youngest and oldest drivers to start, win, take pole (grid P1) and finish on the podium. Needs a birth date in the history. Ages are in whole years plus days (a year counted as 365.25 days).
export function ageRecords() {
  load(); const cat = { start: [], win: [], pole: [], podium: [] };
  Object.keys(H.r).forEach((y) => H.r[y].forEach((rc) => { const t = Date.parse(rc[3]); if (!t) return;
    rc[4].forEach((r) => { const dob = H.d[r[0]][3]; const b = dob && Date.parse(dob); if (!b) return; const a = ageParts((t - b) / 864e5); if (a.y < 14 || a.y > 70) return;
      const o = { name: nameOfIdx(r[0]), race: `${rc[1]} ${y}`, ...a }; const p = String(r[4]);
      cat.start.push(o); if (p === '1') cat.win.push(o); if (p === '1' || p === '2' || p === '3') cat.podium.push(o); if (r[2] === 1) cat.pole.push(o); }); }));
  const best = (list, dir) => { const seen = new Set(); return [...list].sort((a, b) => dir * (a.days - b.days)).filter((o) => (seen.has(o.name) ? false : seen.add(o.name))).slice(0, 15); };
  const out = {}; Object.keys(cat).forEach((k) => { out[k] = { youngest: best(cat[k], 1), oldest: best(cat[k], -1) }; }); return out;
}

// Races where one driver took pole (grid P1), won, and set the fastest lap. The fastest-lap flag is only stored for seasons that have it, so older totals may be low.
export function hatTricks() {
  load(); const by = {}; let total = 0;
  Object.keys(H.r).forEach((y) => H.r[y].forEach((rc) => rc[4].forEach((r) => { if (r[2] === 1 && String(r[4]) === '1' && r[7] === 1) { total++; const o = (by[r[0]] ||= { name: nameOfIdx(r[0]), n: 0, years: [], last: '' }); o.n++; o.years.push(+y); o.last = `${rc[1]} ${y}`; } })));
  const rows = Object.values(by).sort((a, b) => b.n - a.n || a.name.localeCompare(b.name)).map((o) => ({ name: o.name, n: o.n, from: Math.min(...o.years), to: Math.max(...o.years), last: o.last }));
  const perYear = {}; Object.keys(H.r).forEach((y) => { let n = 0; H.r[y].forEach((rc) => rc[4].forEach((r) => { if (r[2] === 1 && String(r[4]) === '1' && r[7] === 1) n++; })); if (n) perYear[y] = n; });
  const years = Object.entries(perYear).sort((a, b) => b[1] - a[1] || b[0] - a[0]).slice(0, 12).map(([y, n]) => ({ year: +y, n }));
  return { rows: rows.slice(0, 30), years, total };
}

// A driver's first season, ranked by the share of all points scored that season (so points systems compare). Needs 8 or more starts in that first season.
export function debutSeasons() {
  load(); const first = {}; const tot = {};
  Object.keys(H.r).map(Number).sort((a, b) => a - b).forEach((y) => { const s = {}; let all = 0;
    H.r[y].forEach((rc) => rc[4].forEach((r) => { const p = Number(r[5]) || 0; all += p; const o = (s[r[0]] ||= { n: 0, pts: 0, wins: 0, pod: 0 }); o.n++; o.pts += p; if (String(r[4]) === '1') o.wins++; if (['1', '2', '3'].includes(String(r[4]))) o.pod++; }));
    tot[y] = all; Object.keys(s).forEach((k) => { if (first[k] === undefined) first[k] = { y, ...s[k] }; }); });
  const rows = Object.entries(first).filter(([, o]) => o.n >= 8 && tot[o.y] > 0).map(([k, o]) => ({ name: nameOfIdx(+k), year: o.y, starts: o.n, pts: Math.round(o.pts * 10) / 10, wins: o.wins, podiums: o.pod, share: o.pts / tot[o.y] }));
  return { share: [...rows].sort((a, b) => b.share - a.share).slice(0, 25), wins: rows.filter((r) => r.wins > 0).sort((a, b) => b.wins - a.wins || b.share - a.share).slice(0, 25) };
}

// Share of starts that did not end classified (retired, disqualified, not classified). Drivers with enough starts; withdrawals (W) are ignored.
export function dnfRates() {
  load(); const by = {};
  Object.keys(H.r).forEach((y) => H.r[y].forEach((rc) => rc[4].forEach((r) => { const p = String(r[4]); if (p === 'W') return; const o = (by[r[0]] ||= { n: 0, out: 0, last: 0, first: 9999 }); o.n++; if (Number.isNaN(Number(p))) o.out++; o.last = Math.max(o.last, +y); o.first = Math.min(o.first, +y); })));
  const mk = (min, minLast) => Object.entries(by).filter(([, o]) => o.n >= min && o.last >= minLast).map(([k, o]) => ({ name: nameOfIdx(+k), n: o.n, out: o.out, rate: o.out / o.n, from: o.first, to: o.last }));
  const all = mk(100, 0), modern = mk(60, 2010).filter((o) => o.from >= 2000 || o.to >= 2010);
  return { most: [...all].sort((a, b) => b.rate - a.rate).slice(0, 20), least: [...all].sort((a, b) => a.rate - b.rate).slice(0, 20), mostNow: [...modern].sort((a, b) => b.rate - a.rate).slice(0, 15), leastNow: [...modern].sort((a, b) => a.rate - b.rate).slice(0, 15) };
}

// Per team (history team id): its name, and per season the points all its drivers scored, wins, and share of all points that season.
export function teamSeasons() {
  load(); const out = {}; const years = Object.keys(H.r).map(Number).sort((a, b) => a - b);
  years.forEach((y) => { let all = 0; const s = {};
    H.r[String(y)].forEach((rc) => rc[4].forEach((r) => { const p = Number(r[5]) || 0; all += p; const o = (s[r[1]] ||= { pts: 0, wins: 0 }); o.pts += p; if (String(r[4]) === '1') o.wins++; }));
    Object.keys(s).forEach((k) => { const id = H.t[k][0]; const t = (out[id] ||= { id, name: H.t[k][1], years: [] }); t.name = H.t[k][1]; t.years.push({ y, pts: Math.round(s[k].pts * 10) / 10, wins: s[k].wins, share: all ? s[k].pts / all : 0 }); }); });
  return Object.values(out).filter((t) => t.years.length >= 2).sort((a, b) => b.years.reduce((n, x) => n + x.wins, 0) - a.years.reduce((n, x) => n + x.wins, 0));
}

// Every Grand Prix name with how many times it was run, then every edition of one of them.
export function gpList() {
  load(); const n = {}; Object.keys(H.r).forEach((y) => H.r[y].forEach((rc) => { n[rc[1]] = (n[rc[1]] || 0) + 1; }));
  return Object.entries(n).map(([name, editions]) => ({ name, editions })).filter((x) => x.editions >= 2).sort((a, b) => b.editions - a.editions || a.name.localeCompare(b.name));
}
export function gpEditions(raceName) {
  load(); const rows = [];
  Object.keys(H.r).sort((a, b) => b - a).forEach((y) => H.r[y].forEach((rc) => { if (rc[1] !== raceName) return;
    const w = rc[4].find((r) => String(r[4]) === '1'); const p = rc[4].find((r) => r[2] === 1); const f = rc[4].find((r) => r[7] === 1);
    rows.push({ year: +y, date: rc[3], winner: w ? nameOfIdx(w[0]) : null, team: w ? H.t[w[1]][1] : '', winGrid: w ? w[2] : null, pole: p ? nameOfIdx(p[0]) : null, poleFin: p ? String(p[4]) : null, fastest: f ? nameOfIdx(f[0]) : null, starters: rc[4].length }); }));
  const wins = {}; rows.forEach((r) => { if (r.winner) wins[r.winner] = (wins[r.winner] || 0) + 1; });
  const most = Object.entries(wins).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([name, n]) => ({ name, n }));
  const back = rows.filter((r) => r.winGrid > 0).sort((a, b) => b.winGrid - a.winGrid)[0] || null;
  const poleWins = rows.filter((r) => r.pole && r.poleFin === '1').length, poleN = rows.filter((r) => r.pole).length;
  return { rows, most, back, poleWins, poleN };
}

// Drivers ranked by how many different teams (history team ids) they raced for, with the order they raced for them. Needs 20 or more starts.
export function journeymen() {
  load(); const out = [];
  H.d.forEach((d, i) => { const L = perDriver().per[i] || []; if (L.length < 20) return; const ids = new Set(), seq = []; L.forEach((x) => { const n = H.t[x.t][1]; ids.add(H.t[x.t][0]); if (seq[seq.length - 1] !== n) seq.push(n); });
    out.push({ name: `${d[1]} ${d[2]}`, teams: ids.size, starts: L.length, trail: seq }); });
  return out.sort((a, b) => b.teams - a.teams || b.starts - a.starts).slice(0, 30);
}

// Average and oldest/youngest driver age on the grid each season, from birth dates, measured at each race and averaged over every start. Drivers without a birth date are skipped.
export function gridAge() {
  load(); const rows = [];
  Object.keys(H.r).map(Number).sort((a, b) => a - b).forEach((y) => { let sum = 0, n = 0, old = null, young = null;
    H.r[String(y)].forEach((rc) => { const t = Date.parse(rc[3]); if (!t) return; rc[4].forEach((r) => { const b = H.d[r[0]][3] && Date.parse(H.d[r[0]][3]); if (!b) return; const age = (t - b) / 864e5 / 365.25; if (age < 14 || age > 70) return; sum += age; n++; const nm = nameOfIdx(r[0]); if (!old || age > old.age) old = { name: nm, age }; if (!young || age < young.age) young = { name: nm, age }; }); });
    if (n > 50) rows.push({ year: y, avg: sum / n, old, young }); });
  return rows;
}

// The calendar by season: races, different countries, Grand Prix names seen for the first time that year.
export function calendarGrowth() {
  load(); const seen = new Set(); const rows = [];
  Object.keys(H.r).map(Number).sort((a, b) => a - b).forEach((y) => { const rs = H.r[String(y)]; const fresh = []; rs.forEach((rc) => { if (!seen.has(rc[1])) { seen.add(rc[1]); fresh.push(rc[1]); } });
    rows.push({ year: y, races: rs.length, countries: new Set(rs.map((rc) => rc[2])).size, fresh }); });
  return rows;
}

let _facts = null;
// Per driver: name, nationality, teams raced for (history team ids and names), wins, podiums, poles (grid P1), starts, titles, first and last season.
export function driverFacts() {
  if (_facts) return _facts; load(); const f = H.d.map((d, i) => ({ idx: i, name: `${d[1]} ${d[2]}`, last: d[2], nat: d[4] || '', teams: new Set(), teamNames: new Set(), wins: 0, podiums: 0, poles: 0, starts: 0, titles: 0, first: 9999, lastYear: 0 }));
  Object.keys(H.r).forEach((y) => H.r[y].forEach((rc) => rc[4].forEach((r) => { const o = f[r[0]]; o.starts++; o.teams.add(H.t[r[1]][0]); o.teamNames.add(H.t[r[1]][1]); const p = String(r[4]); if (p === '1') o.wins++; if (p === '1' || p === '2' || p === '3') o.podiums++; if (r[2] === 1) o.poles++; o.first = Math.min(o.first, +y); o.lastYear = Math.max(o.lastYear, +y); })));
  Object.keys(H.ds).forEach((y) => { try { const id = driverChampion(+y); const i = id ? dIdx(id) : -1; if (i >= 0 && f[i]) f[i].titles++; } catch {} });
  _facts = f.filter((o) => o.starts > 0); return _facts;
}
// A random past race with the facts a "guess the year" round shows. `r` is a random function.
export function raceSample(r) {
  load(); const years = Object.keys(H.r).map(Number); const y = years[Math.floor(r() * years.length)]; const rs = H.r[String(y)]; const rc = rs[Math.floor(r() * rs.length)];
  const by = (p) => rc[4].find((x) => String(x[4]) === p); const w = by('1'), s = by('2'), t = by('3'), pole = rc[4].find((x) => x[2] === 1);
  if (!w || !s || !t) return null;
  return { year: y, name: rc[1], winner: nameOfIdx(w[0]), team: H.t[w[1]][1], second: nameOfIdx(s[0]), third: nameOfIdx(t[0]), pole: pole ? nameOfIdx(pole[0]) : null, starters: rc[4].length };
}

// How every constructors' championship was decided (1958 on): winner, runner-up, points margin and the winner's race wins that year. Names follow the team ids in the history, so a renamed team is counted separately.
export function constructorTitleHistory() {
  load(); const rows = [];
  Object.keys(H.cs).map(Number).sort((a, b) => a - b).forEach((y) => { const cs = [...H.cs[String(y)]].sort((a, b) => a[1] - b[1]); const top = cs[0], sec = cs[1]; if (!top || top[1] !== 1 || !sec || !(top[2] > 0)) return;
    const races = H.r[String(y)] || []; let wins = 0; races.forEach((rc) => rc[4].forEach((r) => { if (r[1] === top[0] && String(r[4]) === '1') wins++; }));
    rows.push({ year: y, team: H.t[top[0]][1], tid: top[0], pts: top[2], second: H.t[sec[0]][1], secPts: sec[2], margin: top[2] - sec[2], pct: (top[2] - sec[2]) / top[2], wins, rounds: races.length }); });
  const byTeam = {}; rows.forEach((r) => { (byTeam[r.tid] ||= { team: r.team, years: [] }).years.push(r.year); });
  const teams = Object.values(byTeam).map((o) => { let best = 1, run = 1; for (let i = 1; i < o.years.length; i++) { run = o.years[i] === o.years[i - 1] + 1 ? run + 1 : 1; if (run > best) best = run; } return { team: o.team, n: o.years.length, streak: best, from: o.years[0], to: o.years[o.years.length - 1] }; }).sort((a, b) => b.n - a.n || a.from - b.from);
  const sorted = (f) => [...rows].sort(f).slice(0, 12);
  return { rows: [...rows].sort((a, b) => b.year - a.year), closest: sorted((a, b) => a.pct - b.pct), biggest: sorted((a, b) => b.pct - a.pct), teams };
}

// Season parity: how many different drivers and teams won, and how much one driver dominated. Only seasons with 8 or more rounds.
export function seasonParity() {
  load(); const rows = [];
  Object.keys(H.r).map(Number).sort((a, b) => a - b).forEach((y) => { const races = H.r[String(y)]; if (!races || races.length < 8) return;
    const dw = {}, tw = {}; let n = 0;
    races.forEach((rc) => { const w = rc[4].find((r) => String(r[4]) === '1'); if (!w) return; n++; dw[w[0]] = (dw[w[0]] || 0) + 1; tw[w[1]] = (tw[w[1]] || 0) + 1; });
    if (!n) return; const top = Object.entries(dw).sort((a, b) => b[1] - a[1])[0];
    rows.push({ year: y, rounds: n, drivers: Object.keys(dw).length, teams: Object.keys(tw).length, topName: nameOfIdx(+top[0]), topWins: top[1], share: top[1] / n }); });
  const open = [...rows].sort((a, b) => b.drivers / b.rounds - a.drivers / a.rounds || b.drivers - a.drivers || b.year - a.year).slice(0, 12);
  const mostDrivers = [...rows].sort((a, b) => b.drivers - a.drivers || b.year - a.year).slice(0, 12);
  const oneSided = [...rows].sort((a, b) => b.share - a.share || b.year - a.year).slice(0, 12);
  const avg = rows.length ? rows.reduce((s, r) => s + r.drivers, 0) / rows.length : 0;
  return { rows: rows.sort((a, b) => b.year - a.year), open, mostDrivers, oneSided, avg };
}

// Who wins the first and the last race of each season, and who wins both.
export function openersClosers() {
  load(); const rows = []; const op = {}, cl = {};
  Object.keys(H.r).map(Number).sort((a, b) => a - b).forEach((y) => { const races = H.r[String(y)]; if (!races || races.length < 2) return;
    const win = (rc) => { const w = rc[4].find((r) => String(r[4]) === '1'); return w ? w[0] : -1; };
    const a = win(races[0]), b = win(races[races.length - 1]); if (a < 0 || b < 0) return;
    const ch = driverChampion(y), ci = ch ? dIdx(ch) : -1;
    rows.push({ year: y, opener: nameOfIdx(a), openerRace: races[0][1], closer: nameOfIdx(b), closerRace: races[races.length - 1][1], both: a === b, openerChamp: a === ci, closerChamp: b === ci });
    const oo = (op[a] ||= { name: nameOfIdx(a), n: 0 }); oo.n++; const cc = (cl[b] ||= { name: nameOfIdx(b), n: 0 }); cc.n++; });
  const top = (o) => Object.values(o).sort((a, b) => b.n - a.n || a.name.localeCompare(b.name)).slice(0, 10);
  const n = rows.length;
  return { rows: rows.sort((a, b) => b.year - a.year), openers: top(op), closers: top(cl), both: rows.filter((r) => r.both), n, openerChamps: rows.filter((r) => r.openerChamp).length, closerChamps: rows.filter((r) => r.closerChamp).length };
}

// Points per start. Raw average points, and the average share of the winner's points in each race (so scoring systems compare). Needs 40 or more starts.
export function pointsPerStart() {
  load(); const st = {};
  Object.keys(H.r).forEach((y) => H.r[y].forEach((rc) => { let mx = 0; rc[4].forEach((r) => { const p = Number(r[5]) || 0; if (p > mx) mx = p; });
    rc[4].forEach((r) => { const o = (st[r[0]] ||= { n: 0, pts: 0, share: 0, first: +y, last: +y }); o.n++; const p = Number(r[5]) || 0; o.pts += p; if (mx > 0) o.share += p / mx; if (+y < o.first) o.first = +y; if (+y > o.last) o.last = +y; }); }));
  const all = Object.keys(st).filter((i) => st[i].n >= 40).map((i) => ({ name: nameOfIdx(+i), n: st[i].n, pts: st[i].pts, avg: st[i].pts / st[i].n, share: st[i].share / st[i].n, from: st[i].first, to: st[i].last }));
  return { share: [...all].sort((a, b) => b.share - a.share).slice(0, 25), raw: [...all].sort((a, b) => b.avg - a.avg).slice(0, 25), count: all.length };
}

// Team-mate questions: a driver, a season and a team where exactly one other driver shared the car for 3 or more races (and the driver raced at least half the season).
let _mates = null;
function matePool() {
  if (_mates) return _mates; load(); const out = [];
  Object.keys(H.r).map(Number).filter((y) => y >= 1970).forEach((y) => { const races = H.r[String(y)]; if (!races || races.length < 8) return;
    const byTeam = {}; const allDrv = {}; races.forEach((rc) => rc[4].forEach((r) => { const t = (byTeam[r[1]] ||= {}); t[r[0]] = (t[r[0]] || 0) + 1; allDrv[r[0]] = (allDrv[r[0]] || 0) + 1; }));
    Object.entries(byTeam).forEach(([ti, ds]) => { const big = Object.entries(ds).filter(([, n]) => n >= 3).map(([d, n]) => [+d, n]); if (big.length !== 2) return;
      const sameTeam = new Set(Object.keys(ds).map(Number)); const pool = Object.keys(allDrv).map(Number).filter((d) => allDrv[d] >= 4 && !sameTeam.has(d));
      big.forEach(([d, n], k) => { const m = big[1 - k]; if (n < races.length / 2 || m[1] < 3 || pool.length < 3) return; out.push({ year: y, team: H.t[ti][1], d, m: m[0], pool }); }); }); });
  _mates = out; return out;
}
export function teammateQ(r) {
  const p = matePool(); if (!p.length) return null; const q = p[Math.floor(r() * p.length)]; const opts = [q.m]; let guard = 0;
  while (opts.length < 4 && guard++ < 60) { const c = q.pool[Math.floor(r() * q.pool.length)]; if (!opts.includes(c)) opts.push(c); }
  if (opts.length < 4) return null; for (let i = opts.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [opts[i], opts[j]] = [opts[j], opts[i]]; }
  return { q: `Who was ${nameOfIdx(q.d)}'s team-mate at ${q.team} in ${q.year}?`, options: opts.map(nameOfIdx), answer: opts.indexOf(q.m), why: `${nameOfIdx(q.m)} drove alongside ${nameOfIdx(q.d)} at ${q.team} in ${q.year}.` };
}

// Career bingo. A card is nine clues about a driver's career; each clue is { t, v } and `bingoFits` says whether a driver matches it.
const DEC = (y) => `${Math.floor(y / 10) * 10}s`;
export function bingoFits(c, f) {
  switch (c.t) {
    case 'team': return f.teamNames.has(c.v);
    case 'nat': return f.nat === c.v;
    case 'letter': return f.last.charAt(0).toUpperCase() === c.v;
    case 'title': return f.titles >= 1;
    case 'wins10': return f.wins >= 10;
    case 'winless': return f.wins === 0 && f.starts >= 50;
    case 'pole': return f.poles >= 1;
    case 'podium': return f.podiums >= 1 && f.wins === 0;
    case 'debut': return DEC(f.first) === c.v;
    case 'teams4': return f.teams.size >= 4;
    default: return false;
  }
}
const bingoLabel = (c) => ({ team: `Raced for ${c.v}`, nat: `${c.v} driver`, letter: `Surname starts with ${c.v}`, title: 'World champion', wins10: 'Won 10 or more races', winless: '50+ starts, never won', pole: 'Took a pole position', podium: 'Podium finisher, never a winner', debut: `First raced in the ${c.v}`, teams4: 'Raced for 4 or more teams' }[c.t]);
let _clues = null;
function cluePool() {
  if (_clues) return _clues; const F = driverFacts(); const pool = []; const cnt = (c) => F.filter((f) => bingoFits(c, f)).length;
  const teams = {}, nats = {}, letters = {}, decs = {}; F.forEach((f) => { f.teamNames.forEach((t) => { teams[t] = (teams[t] || 0) + 1; }); nats[f.nat] = (nats[f.nat] || 0) + 1; const l = f.last.charAt(0).toUpperCase(); letters[l] = (letters[l] || 0) + 1; decs[DEC(f.first)] = (decs[DEC(f.first)] || 0) + 1; });
  Object.keys(teams).filter((t) => teams[t] >= 25).forEach((t) => pool.push({ t: 'team', v: t }));
  Object.keys(nats).filter((n) => n && nats[n] >= 15).forEach((n) => pool.push({ t: 'nat', v: n }));
  Object.keys(letters).filter((l) => letters[l] >= 25).forEach((l) => pool.push({ t: 'letter', v: l }));
  Object.keys(decs).filter((d) => decs[d] >= 25).forEach((d) => pool.push({ t: 'debut', v: d }));
  ['title', 'wins10', 'winless', 'pole', 'podium', 'teams4'].forEach((t) => pool.push({ t }));
  _clues = pool.filter((c) => cnt(c) >= 8).map((c) => ({ ...c, label: bingoLabel(c) })); return _clues;
}
export function bingoCard(r) {
  const left = [...cluePool()]; const out = [];
  while (out.length < 9 && left.length) { const c = left.splice(Math.floor(r() * left.length), 1)[0]; if (c.t === 'letter' && out.filter((x) => x.t === 'letter').length >= 2) continue; out.push(c); }
  return out.length === 9 ? out : null;
}
// Drivers whose name contains the typed text, for the answer box.
export function bingoSearch(q, norm) {
  const n = norm(q); if (n.length < 2) return []; return driverFacts().filter((f) => norm(f.name).includes(n)).sort((a, b) => b.starts - a.starts).slice(0, 6).map((f) => ({ idx: f.idx, name: f.name, starts: f.starts }));
}
export function bingoCheck(c, idx) { const f = driverFacts().find((x) => x.idx === idx); return !!f && bingoFits(c, f); }

// Birthday: drivers born on a month and day, and Grands Prix held on that date (any year).
export function birthdayData(month, day) {
  load(); const F = driverFacts(); const mm = String(month).padStart(2, '0'), dd = String(day).padStart(2, '0'); const md = `${mm}-${dd}`;
  const born = F.filter((f) => { const dob = H.d[f.idx][3]; return dob && dob.slice(5) === md; }).map((f) => ({ name: f.name, year: +H.d[f.idx][3].slice(0, 4), starts: f.starts, wins: f.wins, titles: f.titles })).sort((a, b) => b.titles - a.titles || b.wins - a.wins || b.starts - a.starts);
  const races = []; Object.keys(H.r).map(Number).sort((a, b) => a - b).forEach((y) => H.r[String(y)].forEach((rc) => { if (rc[3] && rc[3].slice(5) === md) { const w = rc[4].find((r) => String(r[4]) === '1'); races.push({ year: y, name: rc[1], winner: w ? nameOfIdx(w[0]) : '', team: w ? H.t[w[1]][1] : '' }); } }));
  return { born, races };
}

// One decade: champions, race wins, grid size, retirements, closest title.
export function eraStats(start) {
  load(); const years = Object.keys(H.r).map(Number).filter((y) => y >= start && y < start + 10).sort((a, b) => a - b); if (!years.length) return null;
  const dw = {}, tw = {}; let races = 0, cars = 0, fin = 0, winners = 0;
  years.forEach((y) => { const set = new Set(); H.r[String(y)].forEach((rc) => { races++; cars += rc[4].length; rc[4].forEach((r) => { if (/^\d+$/.test(String(r[4]))) fin++; if (String(r[4]) === '1') { dw[r[0]] = (dw[r[0]] || 0) + 1; tw[r[1]] = (tw[r[1]] || 0) + 1; set.add(r[0]); } }); }); winners += set.size; });
  const top = (o, nm) => Object.entries(o).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([k, n]) => ({ name: nm(+k), n }));
  const champs = years.map((y) => { let id = null; try { id = driverChampion(y); } catch {} const i = id ? dIdx(id) : -1; return { year: y, name: i >= 0 ? nameOfIdx(i) : '' }; }).filter((c) => c.name);
  const th = titleHistory().rows.filter((r) => r.year >= start && r.year < start + 10); const close = [...th].sort((a, b) => a.pct - b.pct)[0] || null;
  return { years: years.length, from: years[0], to: years[years.length - 1], races, perSeason: races / years.length, cars: cars / races, finishRate: fin / cars, winnersPerYear: winners / years.length, champs, drivers: top(dw, nameOfIdx), teams: top(tw, (k) => H.t[k][1]), close };
}

// Draft duel: one real race with a pool of 12 of its drivers (4 from the top 6, 4 from 7th to 12th, 4 from the rest). `r` is a random function.
export function draftRace(r) {
  load(); const years = Object.keys(H.r).map(Number).filter((y) => y >= 1970);
  for (let t = 0; t < 40; t++) { const y = years[Math.floor(r() * years.length)]; const rs = H.r[String(y)]; const rc = rs[Math.floor(r() * rs.length)]; const rows = [...rc[4]].filter((x) => /^\d+$/.test(String(x[4]))).sort((a, b) => Number(a[4]) - Number(b[4])); const all = rc[4];
    if (rows.length < 14 || all.length < 16) continue;
    const take = (list, n) => { const l = [...list], o = []; while (o.length < n && l.length) o.push(l.splice(Math.floor(r() * l.length), 1)[0]); return o; };
    const top = rows.slice(0, 6), mid = rows.slice(6, 12), low = all.filter((x) => !top.includes(x) && !mid.includes(x));
    const pick = [...take(top, 4), ...take(mid, 4), ...take(low, 4)]; if (pick.length < 12) continue;
    for (let i = pick.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [pick[i], pick[j]] = [pick[j], pick[i]]; }
    return { race: `${rc[1]} ${y}`, pool: pick.map((x) => ({ idx: x[0], name: nameOfIdx(x[0]), team: H.t[x[1]][1], tid: H.t[x[1]][0], pts: Number(x[5]) || 0, pos: /^\d+$/.test(String(x[4])) ? Number(x[4]) : 0, grid: x[2] })) };
  }
  return null;
}

// Tic-tac-toe grid: three row clues and three column clues, where every square has at least two drivers who fit both.
export function gridDuelCard(r) {
  const pool = cluePool(); if (pool.length < 6) return null; const F = driverFacts();
  for (let t = 0; t < 600; t++) { const l = [...pool]; for (let i = l.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [l[i], l[j]] = [l[j], l[i]]; }
    const rows = l.slice(0, 3), cols = l.slice(3, 6); let ok = true;
    outer: for (const a of rows) for (const b of cols) { let n = 0; for (const f of F) { if (bingoFits(a, f) && bingoFits(b, f) && ++n >= 2) break; } if (n < 2) { ok = false; break outer; } }
    if (ok) return { rows, cols }; }
  return null;
}
export const gridFits = (a, b, idx) => { const f = driverFacts().find((x) => x.idx === idx); return !!f && bingoFits(a, f) && bingoFits(b, f); };

// Season heatmap: one row per driver (best championship result first), one cell per round. pos is the classified finish (null when not classified),
// out is true when the car did not finish (retired, disqualified, did not start), grid is the starting slot.
export function seasonHeat(year) {
  load(); const rs = H.r[String(year)]; if (!rs) return null; const by = {};
  rs.forEach((rc, ri) => rc[4].forEach((r) => {
    const o = (by[r[0]] ||= { idx: r[0], cells: Array(rs.length).fill(null), pts: 0, team: r[1] });
    const num = Number(r[4]); const fin = Number.isFinite(num) && num > 0; o.team = r[1]; o.pts += r[5] || 0;
    o.cells[ri] = { pos: fin ? num : null, out: !fin, grid: r[2] > 0 ? r[2] : null, pts: r[5] || 0, status: r[6] || '', fast: r[7] === 1 };
  }));
  const rank = {}, tot = {}; (H.ds[String(year)] || []).forEach((x) => { rank[x[0]] = x[1]; tot[x[0]] = x[2]; }); // official championship position and points (sprints included)
  const rk = (o) => (rank[o.idx] !== undefined ? rank[o.idx] : 999);
  const drivers = Object.values(by).sort((a, b) => rk(a) - rk(b) || b.pts - a.pts || a.idx - b.idx).map((o) => ({ ...o, pts: tot[o.idx] !== undefined ? tot[o.idx] : o.pts, name: `${H.d[o.idx][1]} ${H.d[o.idx][2]}`, code: H.d[o.idx][6] || H.d[o.idx][2].slice(0, 3).toUpperCase(), teamId: H.t[o.team][0], teamName: H.t[o.team][1] }));
  return { rounds: rs.map((rc) => ({ round: rc[0], name: rc[1].replace(' Grand Prix', ''), country: rc[2] })), drivers };
}

// Finds the driver or team a display name belongs to, so rows in any statistic can open the right page. Returns null when the name is not a driver or team.
let _ent = null;
export function entityByName(name) {
  if (!name) return null; load();
  if (!_ent) {
    const dr = {}, tm = {}; H.d.forEach((d) => { const k = `${d[1]} ${d[2]}`.toLowerCase(); if (!dr[k]) dr[k] = { type: 'driver', driverId: d[0], name: `${d[1]} ${d[2]}`, first: d[1], last: d[2] }; });
    H.t.forEach((t) => { const k = String(t[1]).toLowerCase(); if (!tm[k]) tm[k] = { type: 'team', teamId: t[0], name: t[1] }; }); _ent = { dr, tm };
  }
  const k = String(name).trim().toLowerCase(); return _ent.dr[k] || _ent.tm[k] || null;
}

// Team-mate battles for a finished season, from the built-in history. The grid slot stands in for qualifying (a grid penalty can differ from the lap-time order).
export function localBattles(year) {
  load(); const rs = H.r[String(year)]; if (!rs) return null;
  const per = rs.map((rc) => { const rows = rc[4].map((r) => { const d = H.d[r[0]]; return { driverId: d[0], driver: `${d[1]} ${d[2]}`, last: d[2], teamId: H.t[r[1]][0], team: H.t[r[1]][1], grid: r[2] > 0 ? r[2] : 99, position: /^\d+$/.test(String(r[4])) ? Number(r[4]) : 99 }; }); return { round: rc[0], name: rc[1], x: rows, q: rows.map((x) => ({ ...x, position: x.grid })) }; });
  return per;
}
