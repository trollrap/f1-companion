import { useEffect } from 'react';
import { AppState } from 'react-native';
import { useSeason } from '../hooks/useSeason';
import { alertSessions, currentSeason, events as motoEvents } from '../api/motogp';
import { usePrefs } from '../hooks/usePrefs';
import { scheduleSessionAlerts, scheduleBirthdays, notificationsModule } from '../lib/notifications';
import { navRef } from '../lib/navRef';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFavs } from '../hooks/useFavs';
import { bdayItems } from '../lib/bdays';
import { checkResults, syncResultTask } from '../lib/resultAlerts';
import { checkNews } from '../lib/newsAlerts';
// Keeps the device's scheduled alerts in step with the next race and the user's preferences, on every launch.
export default function AlertScheduler() {
  const season = useSeason(); const { prefs } = usePrefs();
  const moto = prefs.opts.sport === 'motogp'; const favs = useFavs();
  // Tapping a news notification opens the story in the in-app reader (which has a link to the original). Also handles a tap that launched the app from closed.
  useEffect(() => {
    const n = notificationsModule(); if (!n) return undefined; let dead = false;
    const open = (item, tries = 0) => { if (dead) return; if (navRef.isReady()) navRef.navigate('Article', { item }); else if (tries < 25) setTimeout(() => open(item, tries + 1), 400); };
    const go = async (resp) => {
      try {
        const id = resp && resp.notification && resp.notification.request && resp.notification.request.identifier; const d = resp && resp.notification.request.content.data;
        if (!id || !d || !d.item) return;
        if ((await AsyncStorage.getItem('lastTapId')) === id) return; await AsyncStorage.setItem('lastTapId', id); open(d.item);
      } catch {}
    };
    try { n.getLastNotificationResponseAsync().then(go).catch(() => {}); } catch {}
    let sub = null; try { sub = n.addNotificationResponseReceivedListener(go); } catch {}
    return () => { dead = true; if (sub) sub.remove(); };
  }, []);
  // Birthdays and first-win anniversaries of favourite drivers (Settings > Notifications). Off by default; turning it off clears them.
  useEffect(() => { try { scheduleBirthdays(prefs.opts.bdays ? bdayItems(favs.drivers) : []).catch(() => {}); } catch {} }, [!!prefs.opts.bdays, JSON.stringify(favs.drivers || [])]);
  useEffect(() => {
    if (moto || prefs.opts.sport === 'football') return;
    if (season.status !== 'ready' || !season.next) return;
    scheduleSessionAlerts(season.next, season.sessions, prefs).catch(() => {});
  }, [moto, season.status, season.next?.meeting_key, season.sessions, prefs]);
  // MotoGP mode: alerts follow the next MotoGP weekend instead (one sport at a time).
  useEffect(() => {
    if (!moto) return undefined; let dead = false;
    (async () => {
      const s = await currentSeason(); if (!s || dead) return;
      const next = (await motoEvents(s.id, s.year)).find((e) => Date.parse(e.end) >= Date.now()); if (!next || dead) return;
      const list = await alertSessions(next, s.id); if (dead) return;
      await scheduleSessionAlerts({ meeting_name: next.name, meeting_key: next.id }, list, prefs);
    })().catch(() => {});
    return () => { dead = true; };
  }, [moto, prefs]);
  // Results alerts: background task on or off with the switch, plus a check at launch and whenever the app comes back to the front.
  useEffect(() => {
    const anyNews = Object.values(prefs.opts?.newsAlerts || {}).some(Boolean);
    syncResultTask(prefs.results || anyNews);
    if (!prefs.results && !anyNews) return undefined;
    const run = () => { checkResults().catch(() => {}); checkNews().catch(() => {}); };
    run();
    const sub = AppState.addEventListener('change', (st) => { if (st === 'active') run(); });
    const timer = setInterval(run, 5 * 60 * 1000); // while the app is open, look every five minutes
    return () => { sub.remove(); clearInterval(timer); };
  }, [prefs.results, JSON.stringify(prefs.opts?.newsAlerts || {})]);
  return null;
}
