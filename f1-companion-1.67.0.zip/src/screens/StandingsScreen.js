import SpoilerGuard from '../components/SpoilerGuard';
import React, { useEffect, useState } from 'react';
import { View, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Skeleton from '../components/Skeleton';
import { Text } from '../components/Text';
import Screen, { ErrorNote, Card, Eyebrow, Note } from '../components/Screen';
import Press from '../components/Press';
import SeasonSwitch from '../components/SeasonSwitch';
import { Segmented, ResultLine } from '../components/Shared';
import { useAsync } from '../hooks/useAsync';
import { useFavs } from '../hooks/useFavs';
import { usePrefs } from '../hooks/usePrefs';
import { useSeason } from '../hooks/useSeason';
import { useTeamColor } from '../hooks/useTeams';
import { driverStandings, constructorStandings } from '../api/jolpica';
import { YEAR } from '../api/openf1';
import { clinched } from '../lib/champion';
import { colors, alpha } from '../theme';
import Grad from '../components/Grad';
import CountUp from '../components/CountUp';
import { HeadShot } from '../components/Shared';

// One tappable label that cycles through the ways of showing the gap.
const modes = (teams) => [['leader', 'Gap to leader'], ['ahead', teams ? 'Interval to team ahead' : 'Interval to car ahead']];
export default function StandingsScreen({ navigation }) {
  const { prefs, setOpt } = usePrefs(); const season = useSeason();
  const [seg, setSeg] = useState('drivers'); const [year, setYear] = useState(YEAR);
  const [mode, setMode] = useState(prefs.opts?.gap === 'ahead' ? 'ahead' : 'leader');
  const favs = useFavs(); const tc = useTeamColor(); const cur = year === YEAR;
  // Leaving the tab for another tab brings back the current season; opening a driver or team page from here does not.
  useEffect(() => navigation.addListener('blur', () => {
    const st = navigation.getState();
    if (st?.routes?.[st.index]?.name !== 'Standings') setYear(YEAR);
  }), [navigation]);
  const switchSeg = (v) => { setSeg(v); if (v === 'teams' && year < 1958) setYear(1958); };
  useEffect(() => { driverStandings(YEAR - 1).catch(() => {}); constructorStandings(YEAR - 1).catch(() => {}); }, []); // warm the cache so the first look at last season is quick
  const d = useAsync(() => driverStandings(year), [year]); const t = useAsync(() => constructorStandings(year), [year]);
  const teams = seg === 'teams'; const st = teams ? t : d; const rows = st.v || [];
  const M = modes(teams), label = M.find(([k]) => k === mode)[1];
  // Points are the big number; the gap sits underneath.
  const right = (r) => `${r.points}`;
  const sub = (r, i) => (i === 0 ? 'Leader' : `−${mode === 'leader' ? rows[0].points - r.points : rows[i - 1].points - r.points}`);
  const next = () => { const k = M[(M.findIndex(([k]) => k === mode) + 1) % M.length][0]; setMode(k); if (k === 'leader' || k === 'ahead') setOpt('gap', k); };
  // Past seasons: the final table, so the leader is the champion. This season: only once it is mathematically decided.
  const won = rows.length > 0 && (cur ? rows.length > 1 && clinched(rows, teams ? 'constructor' : 'driver', season.races?.length, season.races) : true);
  return (
    <Screen swipe={{ index: teams ? 1 : 0, count: 2, onIndex: (i) => switchSeg(i ? 'teams' : 'drivers') }}>
      <SeasonSwitch year={year} onChange={setYear} min={teams ? 1958 : 1950} max={YEAR} />
      <Segmented value={seg} onChange={switchSeg} items={[['drivers', 'Drivers'], ['teams', 'Teams']]} />
      {(
        <View style={{ flexDirection: 'row', gap: 10 }}>
          {[['Chart', 'stats-chart', 'Season chart', { kind: seg, year }], ...(cur ? [['WhatIf', 'git-branch-outline', 'What if…', undefined]] : [])].map(([r, ic, l, p]) => (
            <View key={r} style={{ flex: 1 }}>
              <Press onPress={() => navigation.navigate(r, p)}>
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 46, borderRadius: 14, backgroundColor: colors.accentSoft, borderWidth: 1, borderColor: colors.accent }}>
                  <Ionicons name={ic} size={18} color={colors.accent} /><Text style={{ color: colors.fg, fontWeight: '700', fontSize: 16 }}>{l}</Text>
                </View>
              </Press>
            </View>))}
        </View>)}
      {rows.length ? (
        <SpoilerGuard id="standings" label="Standings hidden">
          <Press onPress={() => (teams ? navigation.navigate('Team', { teamId: rows[0].teamId, name: rows[0].name, year: cur ? undefined : year }) : navigation.navigate('Driver', { driverId: rows[0].driverId, name: rows[0].name, first: rows[0].first, last: rows[0].last, teamId: rows[0].teamId, team: rows[0].team, year: cur ? undefined : year }))} accessibilityLabel="Open the leader">
            <Grad color={tc(rows[0].teamId)} from={0.5} to={0.05} radius={26} border={0.45} style={{ padding: 16, flexDirection: 'row', alignItems: 'center', gap: 14 }}>
              {!teams ? <HeadShot id={rows[0].driverId} size={72} color={tc(rows[0].teamId)} /> : null}
              <View style={{ flex: 1 }}>
                <Text style={{ color: won ? colors.gold : colors.onSoft, fontSize: 11, fontWeight: '800', letterSpacing: 1.8 }}>{won ? (cur ? 'CHAMPION' : `CHAMPION ${year}`) : 'LEADER'}</Text>
                <Text style={{ color: colors.fg, fontSize: 22, fontWeight: '800' }} numberOfLines={1}>{teams ? rows[0].name : `${rows[0].first} ${rows[0].last}`}</Text>
                {!teams && rows[0].team ? <Text style={{ color: colors.onSoft, fontSize: 13 }} numberOfLines={1}>{rows[0].team}</Text> : null}
              </View>
              <View style={{ alignItems: 'flex-end' }}><CountUp value={rows[0].points} style={{ color: colors.fg, fontSize: 30, fontWeight: '800' }} /><Text style={{ color: alpha(colors.fg, 0.6), fontSize: 10, letterSpacing: 1.5 }}>PTS</Text></View>
            </Grad>
          </Press>
        </SpoilerGuard>) : null}
      <Card>
        <Eyebrow>{teams ? `${year} teams` : `${year} drivers`}</Eyebrow>
        <Pressable onPress={next} hitSlop={8} accessibilityRole="button" accessibilityLabel={`Showing ${label}. Tap to change.`} style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 10, alignSelf: 'flex-start', opacity: pressed ? 0.6 : 1 })}>
          <Ionicons name="swap-vertical" size={16} color={colors.accent} />
          <Text style={{ color: colors.accent, fontWeight: '700', fontSize: 17 }}>{label}</Text>
          <Text style={{ color: colors.muted, fontSize: 14 }}>· tap to change</Text>
        </Pressable>
        {st.loading && <Skeleton />}
        {st.error && <ErrorNote error={st.error} onRetry={st.reload} />}
        {st.v && !rows.length && <Note>{year > YEAR ? 'Standings start after the first race of the season.' : 'No standings published for this season.'}</Note>}
        <SpoilerGuard id="standings" label="Standings hidden"><View style={{ marginTop: 6 }}>
          {rows.map((r, i) => {
            const champion = won && i === 0;
            return teams
              ? <ResultLine key={r.teamId} index={i} pos={r.position} first="" last={r.name} color={tc(r.teamId)} right={right(r)} sub={sub(r, i)} fav={favs.isTeam(r.teamId)} champion={champion} midLogoId={cur ? r.teamId : undefined} slotLogoId={cur ? undefined : r.teamId}
                  onPress={() => navigation.navigate('Team', { teamId: r.teamId, name: r.name, year: cur ? undefined : year })} />
              : <ResultLine key={r.driverId} index={i} pos={r.position} first={r.first} last={r.last} color={tc(r.teamId)} right={right(r)} sub={sub(r, i)} fav={favs.isDriver(r.driverId)} champion={champion} photoId={cur ? r.driverId : undefined} logoId={cur ? r.teamId : undefined} slotLogoId={cur ? undefined : r.teamId}
                  onPress={() => navigation.navigate('Driver', { driverId: r.driverId, name: r.name, first: r.first, last: r.last, teamId: r.teamId, team: r.team, year: cur ? undefined : year })} />;
          })}
        </View></SpoilerGuard>
      </Card>
    </Screen>
  );
}
